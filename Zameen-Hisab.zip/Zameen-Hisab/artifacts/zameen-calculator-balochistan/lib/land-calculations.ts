export type AreaUnitCode = 'sqft' | 'marla' | 'kanal' | 'acre' | 'sqm';

export const AREA_UNITS: {
  code: AreaUnitCode;
  english: string;
  urdu: string;
  short: string;
  squareFeet: number;
}[] = [
  { code: 'sqft', english: 'Sq Feet', urdu: 'مربع فٹ', short: 'sq ft', squareFeet: 1 },
  { code: 'marla', english: 'Marla', urdu: 'مرلہ', short: 'marla', squareFeet: 272 },
  { code: 'kanal', english: 'Kanal', urdu: 'کنال', short: 'kanal', squareFeet: 5440 },
  { code: 'acre', english: 'Acre', urdu: 'ایکڑ', short: 'acre', squareFeet: 43520 },
  { code: 'sqm', english: 'Sq Meter', urdu: 'مربع میٹر', short: 'm²', squareFeet: 10.76391041671 },
];

export function convertArea(
  amount: number,
  from: AreaUnitCode,
  to: AreaUnitCode,
): number {
  const fromUnit = AREA_UNITS.find((unit) => unit.code === from);
  const toUnit = AREA_UNITS.find((unit) => unit.code === to);
  if (!fromUnit || !toUnit) {
    throw new Error('Unsupported area unit.');
  }
  return (amount * fromUnit.squareFeet) / toUnit.squareFeet;
}

export function parseNumber(value: string): number | null {
  const normalized = value.replace(/,/g, '').trim();
  if (!normalized) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 2,
  }).format(value);
}