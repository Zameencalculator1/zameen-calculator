import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import {
  ActionButton,
  CalculatorPage,
  ErrorMessage,
  NumberField,
  ResultPanel,
  ResultRow,
} from '@/components/CalculatorUI';
import { useColors } from '@/hooks/useColors';
import {
  AREA_UNITS,
  AreaUnitCode,
  convertArea,
  formatNumber,
  parseNumber,
} from '@/lib/land-calculations';

type UnitPickerProps = {
  headingEnglish: string;
  headingUrdu: string;
  value: AreaUnitCode;
  onChange: (unit: AreaUnitCode) => void;
};

function UnitPicker({
  headingEnglish,
  headingUrdu,
  value,
  onChange,
}: UnitPickerProps) {
  const colors = useColors();
  return (
    <View style={pickerStyles.group}>
      <Text style={[pickerStyles.heading, { color: colors.foreground }]}>
        {headingEnglish}
        <Text style={{ color: colors.mutedForeground }}>{'  '}· {headingUrdu}</Text>
      </Text>
      <View style={pickerStyles.options}>
        {AREA_UNITS.map((unit) => {
          const selected = unit.code === value;
          return (
            <Pressable
              key={unit.code}
              onPress={() => onChange(unit.code)}
              accessibilityRole="radio"
              accessibilityState={{ selected }}
              accessibilityLabel={`${unit.english}, ${unit.urdu}`}
              style={({ pressed }) => [
                pickerStyles.option,
                {
                  backgroundColor: selected ? colors.primary : colors.card,
                  borderColor: selected ? colors.primary : colors.border,
                  opacity: pressed ? 0.84 : 1,
                },
              ]}
            >
              <Text
                numberOfLines={1}
                style={[
                  pickerStyles.optionEnglish,
                  { color: selected ? colors.primaryForeground : colors.foreground },
                ]}
              >
                {unit.english}
              </Text>
              <Text
                numberOfLines={1}
                style={[
                  pickerStyles.optionUrdu,
                  { color: selected ? colors.primaryForeground : colors.mutedForeground },
                ]}
              >
                {unit.urdu}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export default function ConverterScreen() {
  const [amount, setAmount] = useState('');
  const [from, setFrom] = useState<AreaUnitCode>('sqft');
  const [to, setTo] = useState<AreaUnitCode>('marla');
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState('');
  const fromUnit = AREA_UNITS.find((unit) => unit.code === from)!;
  const toUnit = AREA_UNITS.find((unit) => unit.code === to)!;

  function calculateConversion() {
    const amountValue = parseNumber(amount);
    if (amountValue === null || amountValue < 0) {
      setResult(null);
      setError('Enter a valid area, zero or more. · درست رقبہ درج کریں۔');
      return;
    }
    setError('');
    setResult(convertArea(amountValue, from, to));
  }

  function changeUnits(nextFrom: AreaUnitCode, nextTo: AreaUnitCode) {
    setFrom(nextFrom);
    setTo(nextTo);
    setResult(null);
    setError('');
  }

  return (
    <CalculatorPage
      titleEnglish="Area converter"
      titleUrdu="رقبہ تبدیل کریں"
      subtitleEnglish="Convert between local land units and metric units."
      subtitleUrdu="زمین کی اکائیوں اور میٹرک اکائیوں میں تبدیل کریں۔"
      icon="repeat"
    >
      <NumberField
        labelEnglish="Area to convert"
        labelUrdu="تبدیل کرنے کا رقبہ"
        value={amount}
        onChangeText={(value) => {
          setAmount(value);
          setResult(null);
          setError('');
        }}
        placeholder="e.g. 1,000"
        accessibilityHint="Enter the area amount to convert."
      />
      <UnitPicker
        headingEnglish="From"
        headingUrdu="سے"
        value={from}
        onChange={(unit) => changeUnits(unit, to)}
      />
      <UnitPicker
        headingEnglish="To"
        headingUrdu="میں"
        value={to}
        onChange={(unit) => changeUnits(from, unit)}
      />
      <ErrorMessage>{error}</ErrorMessage>
      <ActionButton
        labelEnglish="Convert area"
        labelUrdu="رقبہ تبدیل کریں"
        icon="repeat"
        onPress={calculateConversion}
      />
      {result !== null ? (
        <ResultPanel titleEnglish="Converted area" titleUrdu="تبدیل شدہ رقبہ">
          <ResultRow
            labelEnglish={toUnit.english}
            labelUrdu={toUnit.urdu}
            value={`${formatNumber(result)} ${toUnit.short}`}
            prominent
          />
          <ResultRow
            labelEnglish="Conversion"
            labelUrdu="تبدیلی"
            value={`${formatNumber(parseNumber(amount) ?? 0)} ${fromUnit.short} = ${formatNumber(result)} ${toUnit.short}`}
          />
        </ResultPanel>
      ) : null}
    </CalculatorPage>
  );
}

const pickerStyles = StyleSheet.create({
  group: { gap: 9 },
  heading: { fontSize: 14, lineHeight: 20, fontWeight: '600' },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  option: {
    width: '31.5%',
    minHeight: 61,
    borderWidth: 1,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
    paddingVertical: 7,
  },
  optionEnglish: { fontSize: 12, lineHeight: 17, fontWeight: '700' },
  optionUrdu: { fontSize: 12, lineHeight: 17 },
});