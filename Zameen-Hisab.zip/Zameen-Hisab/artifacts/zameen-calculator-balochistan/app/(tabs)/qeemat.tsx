import React, { useState } from 'react';
import {
  ActionButton,
  CalculatorPage,
  ErrorMessage,
  NumberField,
  ResultPanel,
  ResultRow,
} from '@/components/CalculatorUI';
import { formatNumber, parseNumber } from '@/lib/land-calculations';

export default function QeematScreen() {
  const [marla, setMarla] = useState('');
  const [pricePerMarla, setPricePerMarla] = useState('');
  const [total, setTotal] = useState<number | null>(null);
  const [error, setError] = useState('');

  function calculatePrice() {
    const marlaValue = parseNumber(marla);
    const priceValue = parseNumber(pricePerMarla);
    if (
      marlaValue === null ||
      priceValue === null ||
      marlaValue <= 0 ||
      priceValue < 0
    ) {
      setTotal(null);
      setError('Enter a valid Marla amount and price. · مرلہ اور قیمت درست درج کریں۔');
      return;
    }
    setError('');
    setTotal(marlaValue * priceValue);
  }

  return (
    <CalculatorPage
      titleEnglish="Land price"
      titleUrdu="زمین کی قیمت"
      subtitleEnglish="Multiply the land area by its price per Marla."
      subtitleUrdu="کل قیمت کے لیے مرلہ اور فی مرلہ قیمت درج کریں۔"
      icon="dollar-sign"
    >
      <NumberField
        labelEnglish="Total Marla"
        labelUrdu="کل مرلہ"
        value={marla}
        onChangeText={(value) => {
          setMarla(value);
          setTotal(null);
          setError('');
        }}
        placeholder="e.g. 10"
        unit="Marla"
        accessibilityHint="Enter the total land area in Marla."
      />
      <NumberField
        labelEnglish="Price per Marla"
        labelUrdu="فی مرلہ قیمت"
        value={pricePerMarla}
        onChangeText={(value) => {
          setPricePerMarla(value);
          setTotal(null);
          setError('');
        }}
        placeholder="e.g. 250,000"
        unit="PKR"
        accessibilityHint="Enter the price of one Marla in Pakistani rupees."
      />
      <ErrorMessage>{error}</ErrorMessage>
      <ActionButton
        labelEnglish="Calculate price"
        labelUrdu="قیمت معلوم کریں"
        icon="arrow-right"
        onPress={calculatePrice}
      />
      {total !== null ? (
        <ResultPanel titleEnglish="Total price" titleUrdu="کل قیمت">
          <ResultRow
            labelEnglish="Total payable"
            labelUrdu="کل رقم"
            value={`PKR ${formatNumber(total)}`}
            prominent
          />
          <ResultRow
            labelEnglish="Land area"
            labelUrdu="رقبہ"
            value={`${formatNumber(parseNumber(marla) ?? 0)} Marla`}
          />
        </ResultPanel>
      ) : null}
    </CalculatorPage>
  );
}