import React, { useState } from 'react';
import {
  ActionButton,
  CalculatorPage,
  ErrorMessage,
  NumberField,
  ResultPanel,
  ResultRow,
} from '@/components/CalculatorUI';
import { formatNumber, parseNumber } from '@/lib/land-calculations';

export default function NaapScreen() {
  const [length, setLength] = useState('');
  const [width, setWidth] = useState('');
  const [area, setArea] = useState<number | null>(null);
  const [error, setError] = useState('');

  function calculateArea() {
    const lengthValue = parseNumber(length);
    const widthValue = parseNumber(width);
    if (
      lengthValue === null ||
      widthValue === null ||
      lengthValue <= 0 ||
      widthValue <= 0
    ) {
      setArea(null);
      setError('Enter a valid length and width greater than zero. · درست لمبائی اور چوڑائی درج کریں۔');
      return;
    }
    setError('');
    setArea(lengthValue * widthValue);
  }

  return (
    <CalculatorPage
      titleEnglish="Land measurement"
      titleUrdu="زمین کی پیمائش"
      subtitleEnglish="Measure a plot using its length and width in feet."
      subtitleUrdu="لمبائی اور چوڑائی فٹ میں درج کریں۔"
      icon="maximize-2"
    >
      <NumberField
        labelEnglish="Length"
        labelUrdu="لمبائی"
        value={length}
        onChangeText={(value) => {
          setLength(value);
          setArea(null);
          setError('');
        }}
        placeholder="e.g. 100"
        unit="ft"
        accessibilityHint="Enter the land length in feet."
      />
      <NumberField
        labelEnglish="Width"
        labelUrdu="چوڑائی"
        value={width}
        onChangeText={(value) => {
          setWidth(value);
          setArea(null);
          setError('');
        }}
        placeholder="e.g. 50"
        unit="ft"
        accessibilityHint="Enter the land width in feet."
      />
      <ErrorMessage>{error}</ErrorMessage>
      <ActionButton
        labelEnglish="Hisab Karo"
        labelUrdu="حساب کریں"
        icon="arrow-right"
        onPress={calculateArea}
      />
      {area !== null ? (
        <ResultPanel titleEnglish="Land area" titleUrdu="رقبہ">
          <ResultRow
            labelEnglish="Square feet"
            labelUrdu="مربع فٹ"
            value={`${formatNumber(area)} sq ft`}
            prominent
          />
          <ResultRow
            labelEnglish="Marla"
            labelUrdu="مرلہ"
            value={formatNumber(area / 272)}
          />
          <ResultRow
            labelEnglish="Kanal"
            labelUrdu="کنال"
            value={formatNumber(area / 272 / 20)}
          />
          <ResultRow
            labelEnglish="Acre"
            labelUrdu="ایکڑ"
            value={formatNumber(area / 272 / 20 / 8)}
          />
        </ResultPanel>
      ) : null}
    </CalculatorPage>
  );
}
