import React from 'react';
import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  type ColorValue,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type TabLabelProps = { color: ColorValue; urdu: string; english: string };

function TabLabel({ color, urdu, english }: TabLabelProps) {
  return (
    <View style={styles.label}>
      <Text style={[styles.urduLabel, { color }]}>{urdu}</Text>
      <Text style={[styles.englishLabel, { color }]}>{english}</Text>
    </View>
  );
}

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === 'web';
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarShowLabel: true,
        tabBarLabelPosition: 'below-icon',
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          elevation: 0,
          height: isWeb ? 84 : 66 + insets.bottom,
          paddingTop: 7,
          paddingBottom: isWeb ? 34 : Math.max(insets.bottom, 7),
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Naap',
          tabBarIcon: ({ color }) => (
            <Feather name="maximize-2" size={21} color={color} />
          ),
          tabBarLabel: ({ color }) => (
            <TabLabel color={color} urdu="ناپ" english="Naap" />
          ),
        }}
      />
      <Tabs.Screen
        name="qeemat"
        options={{
          title: 'Qeemat',
          tabBarIcon: ({ color }) => (
            <Feather name="dollar-sign" size={21} color={color} />
          ),
          tabBarLabel: ({ color }) => (
            <TabLabel color={color} urdu="قیمت" english="Qeemat" />
          ),
        }}
      />
      <Tabs.Screen
        name="converter"
        options={{
          title: 'Converter',
          tabBarIcon: ({ color }) => (
            <Feather name="repeat" size={21} color={color} />
          ),
          tabBarLabel: ({ color }) => (
            <TabLabel color={color} urdu="تبدیل" english="Convert" />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  label: {
    alignItems: 'center',
    minWidth: 58,
  },
  urduLabel: {
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '600',
  },
  englishLabel: {
    fontSize: 10,
    lineHeight: 13,
    fontWeight: '500',
  },
});
