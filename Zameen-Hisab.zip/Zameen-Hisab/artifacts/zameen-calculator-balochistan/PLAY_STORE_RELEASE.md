# Google Play release build

This Expo project includes a generated Android Studio project under `android/`.
The existing application ID is `com.zameencalculator.app`; keep it unchanged
for this Play Store listing.

## Requirements

- Android Studio with the Android SDK versions required by the generated
  Gradle project
- A compatible JDK (Android Studio's bundled JDK is suitable)
- Node.js and pnpm, with the full workspace dependencies installed

From the repository root, run `pnpm install` before building. Then open
`artifacts/zameen-calculator-balochistan/android` in Android Studio, or use
the Gradle wrapper commands below from that directory.

## Create a private upload key

Create a dedicated upload key on the computer that will build the release.
The command prompts for the passwords; do not put passwords in the command:

```sh
keytool -genkeypair -v -storetype JKS -keystore upload-keystore.jks -alias zameen-upload -keyalg RSA -keysize 2048 -validity 10000
```

Copy `keystore.properties.example` to `keystore.properties` in the `android/`
directory. Fill in the prompted values:

```properties
storeFile=upload-keystore.jks
storePassword=YOUR_KEYSTORE_PASSWORD
keyAlias=zameen-upload
keyPassword=YOUR_KEY_PASSWORD
```

Both `keystore.properties` and keystore files are excluded from Git. Keep the
keystore and its passwords private and make a secure backup. Do not send them
in chat or commit them to the repository. When creating the Play Store listing,
enable Google Play App Signing and use this key as the upload key.

## Build

In the `android/` directory:

```sh
./gradlew bundleRelease
```

On Windows, run `gradlew.bat bundleRelease`. The signed Play Store bundle is
written to:

```text
app/build/outputs/bundle/release/app-release.aab
```

To build a signed APK for direct installation instead, run
`./gradlew assembleRelease`. Its output is
`app/build/outputs/apk/release/app-release.apk`.

The release tasks stop with a clear error until the upload keystore and all
four signing properties are present. Increment `versionCode` in `app.json`
for each Play Store update.