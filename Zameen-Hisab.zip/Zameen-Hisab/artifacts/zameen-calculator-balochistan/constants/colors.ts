/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#18331B',
    tint: '#2E7D32',

    // Core surfaces
    background: '#F5F8F3',
    foreground: '#18331B',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#18331B',

    // Primary action color (buttons, links, active states)
    primary: '#2E7D32',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E8F1E6',
    secondaryForeground: '#245A28',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EDF3EB',
    mutedForeground: '#5F7160',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#DDEBDD',
    accentForeground: '#245A28',

    // Destructive actions (delete, error states)
    destructive: '#B3261E',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#D9E4D7',
    input: '#C8D8C6',
  },

  dark: {
    text: '#EAF3E8',
    tint: '#75C77A',
    background: '#111A12',
    foreground: '#EAF3E8',
    card: '#1B281C',
    cardForeground: '#EAF3E8',
    primary: '#2E7D32',
    primaryForeground: '#FFFFFF',
    secondary: '#263729',
    secondaryForeground: '#D6E8D4',
    muted: '#233025',
    mutedForeground: '#A2B3A0',
    accent: '#2D4930',
    accentForeground: '#E1F0DF',
    destructive: '#CF6679',
    destructiveForeground: '#FFFFFF',
    border: '#344636',
    input: '#455A46',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
