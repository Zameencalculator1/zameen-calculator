import { Feather } from '@expo/vector-icons';
import React from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

type ScreenIcon = React.ComponentProps<typeof Feather>['name'];

type CalculatorPageProps = {
  titleEnglish: string;
  titleUrdu: string;
  subtitleEnglish: string;
  subtitleUrdu: string;
  icon: ScreenIcon;
  children: React.ReactNode;
};

export function CalculatorPage({
  titleEnglish,
  titleUrdu,
  subtitleEnglish,
  subtitleUrdu,
  icon,
  children,
}: CalculatorPageProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12,
            paddingBottom: Platform.OS === 'web' ? 112 : 28,
          },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.content}>
          <View style={styles.brandRow}>
            <View
              style={[
                styles.brandMark,
                { backgroundColor: colors.primary },
              ]}
            >
              <Feather name="map" size={23} color={colors.primaryForeground} />
            </View>
            <View style={styles.brandCopy}>
              <Text style={[styles.brandName, { color: colors.foreground }]}>
                Zameen Calculator
              </Text>
              <Text style={[styles.brandRegion, { color: colors.mutedForeground }]}>
                بلوچستان · Balochistan
              </Text>
            </View>
            <View
              style={[
                styles.offlinePill,
                {
                  backgroundColor: colors.secondary,
                  borderColor: colors.border,
                },
              ]}
            >
              <Feather name="wifi-off" size={13} color={colors.secondaryForeground} />
              <Text style={[styles.offlineText, { color: colors.secondaryForeground }]}>
                OFFLINE
              </Text>
            </View>
          </View>

          <View style={styles.heading}>
            <View
              style={[
                styles.headingIcon,
                { backgroundColor: colors.accent },
              ]}
            >
              <Feather name={icon} size={22} color={colors.accentForeground} />
            </View>
            <Text style={[styles.screenTitle, { color: colors.foreground }]}>
              {titleEnglish}
            </Text>
            <Text style={[styles.screenUrduTitle, { color: colors.secondaryForeground }]}>
              {titleUrdu}
            </Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              {subtitleEnglish}
            </Text>
            <Text style={[styles.subtitleUrdu, { color: colors.mutedForeground }]}>
              {subtitleUrdu}
            </Text>
          </View>

          <View style={styles.form}>{children}</View>
          <Text style={[styles.footer, { color: colors.mutedForeground }]}>
            حساب اسی فون پر ہوتا ہے · Calculations stay on this phone
          </Text>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

type FieldProps = {
  labelEnglish: string;
  labelUrdu: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  unit?: string;
  accessibilityHint: string;
};

export function NumberField({
  labelEnglish,
  labelUrdu,
  value,
  onChangeText,
  placeholder,
  unit,
  accessibilityHint,
}: FieldProps) {
  const colors = useColors();
  return (
    <View style={styles.field}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
        {labelEnglish}
        <Text style={[styles.fieldUrdu, { color: colors.mutedForeground }]}>
          {'  '}· {labelUrdu}
        </Text>
      </Text>
      <View
        style={[
          styles.inputShell,
          { backgroundColor: colors.card, borderColor: colors.input },
        ]}
      >
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          keyboardType="decimal-pad"
          returnKeyType="done"
          selectTextOnFocus
          accessibilityLabel={`${labelEnglish}, ${labelUrdu}`}
          accessibilityHint={accessibilityHint}
          style={[styles.input, { color: colors.foreground }]}
        />
        {unit ? (
          <View style={[styles.unitTag, { backgroundColor: colors.muted }]}>
            <Text style={[styles.unitText, { color: colors.secondaryForeground }]}>
              {unit}
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}

type ActionButtonProps = {
  labelEnglish: string;
  labelUrdu: string;
  icon: ScreenIcon;
  onPress: () => void;
};

export function ActionButton({
  labelEnglish,
  labelUrdu,
  icon,
  onPress,
}: ActionButtonProps) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${labelEnglish}, ${labelUrdu}`}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor: colors.primary,
          opacity: pressed ? 0.86 : 1,
          transform: [{ scale: pressed ? 0.99 : 1 }],
        },
      ]}
    >
      <Feather name={icon} size={20} color={colors.primaryForeground} />
      <Text style={[styles.actionEnglish, { color: colors.primaryForeground }]}>
        {labelEnglish}
      </Text>
      <Text style={[styles.actionUrdu, { color: colors.primaryForeground }]}>
        {labelUrdu}
      </Text>
    </Pressable>
  );
}

type ErrorMessageProps = { children: string };

export function ErrorMessage({ children }: ErrorMessageProps) {
  const colors = useColors();
  if (!children) return null;
  return (
    <View
      accessibilityRole="alert"
      style={[
        styles.errorBox,
        { backgroundColor: colors.destructive + '12', borderColor: colors.destructive },
      ]}
    >
      <Feather name="alert-circle" size={17} color={colors.destructive} />
      <Text style={[styles.errorText, { color: colors.destructive }]}>{children}</Text>
    </View>
  );
}

type ResultPanelProps = {
  titleEnglish: string;
  titleUrdu: string;
  children: React.ReactNode;
};

export function ResultPanel({
  titleEnglish,
  titleUrdu,
  children,
}: ResultPanelProps) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.resultPanel,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}
    >
      <View style={styles.resultHeading}>
        <Feather name="check-circle" size={18} color={colors.primary} />
        <Text style={[styles.resultTitle, { color: colors.foreground }]}>
          {titleEnglish}
          <Text style={[styles.resultUrduTitle, { color: colors.mutedForeground }]}>
            {'  '}· {titleUrdu}
          </Text>
        </Text>
      </View>
      {children}
    </View>
  );
}

type ResultRowProps = {
  labelEnglish: string;
  labelUrdu: string;
  value: string;
  prominent?: boolean;
};

export function ResultRow({
  labelEnglish,
  labelUrdu,
  value,
  prominent = false,
}: ResultRowProps) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.resultRow,
        { borderBottomColor: colors.border },
        prominent && [styles.prominentRow, { backgroundColor: colors.secondary }],
      ]}
    >
      <View style={styles.resultLabels}>
        <Text
          style={[
            styles.resultLabel,
            { color: prominent ? colors.secondaryForeground : colors.mutedForeground },
          ]}
        >
          {labelEnglish}
        </Text>
        <Text
          style={[
            styles.resultRowUrdu,
            { color: prominent ? colors.secondaryForeground : colors.mutedForeground },
          ]}
        >
          {labelUrdu}
        </Text>
      </View>
      <Text
        selectable
        style={[
          styles.resultValue,
          { color: prominent ? colors.primary : colors.foreground },
          prominent && styles.prominentValue,
        ]}
      >
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 20,
    alignItems: 'center',
    flexGrow: 1,
  },
  content: {
    width: '100%',
    maxWidth: 520,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 28,
  },
  brandMark: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandCopy: { flex: 1 },
  brandName: { fontSize: 16, lineHeight: 20, fontWeight: '700' },
  brandRegion: { fontSize: 12, lineHeight: 17, marginTop: 2 },
  offlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 9,
    paddingVertical: 7,
  },
  offlineText: { fontSize: 9, lineHeight: 12, letterSpacing: 0.6, fontWeight: '700' },
  heading: { marginBottom: 23 },
  headingIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  screenTitle: { fontSize: 28, lineHeight: 35, fontWeight: '700', letterSpacing: -0.5 },
  screenUrduTitle: { fontSize: 19, lineHeight: 27, fontWeight: '600', marginTop: 1 },
  subtitle: { fontSize: 14, lineHeight: 20, marginTop: 10 },
  subtitleUrdu: { fontSize: 14, lineHeight: 22, marginTop: 1 },
  form: { gap: 16 },
  footer: { textAlign: 'center', fontSize: 11, lineHeight: 17, marginTop: 23 },
  field: { gap: 8 },
  fieldLabel: { fontSize: 15, lineHeight: 21, fontWeight: '600' },
  fieldUrdu: { fontSize: 14, fontWeight: '500' },
  inputShell: {
    minHeight: 58,
    borderWidth: 1,
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
  },
  input: { flex: 1, minHeight: 56, fontSize: 18, fontWeight: '600', paddingVertical: 10 },
  unitTag: { borderRadius: 9, paddingHorizontal: 10, paddingVertical: 6 },
  unitText: { fontSize: 13, fontWeight: '700' },
  actionButton: {
    minHeight: 60,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 16,
  },
  actionEnglish: { fontSize: 16, lineHeight: 21, fontWeight: '700' },
  actionUrdu: { fontSize: 15, lineHeight: 21, fontWeight: '700' },
  errorBox: {
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 12,
    paddingVertical: 11,
    flexDirection: 'row',
    gap: 9,
    alignItems: 'center',
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: '500' },
  resultPanel: { borderWidth: 1, borderRadius: 19, padding: 16, gap: 9 },
  resultHeading: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 2 },
  resultTitle: { fontSize: 16, lineHeight: 23, fontWeight: '700' },
  resultUrduTitle: { fontSize: 14, lineHeight: 21, fontWeight: '500' },
  resultRow: {
    minHeight: 54,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    paddingVertical: 7,
  },
  prominentRow: { borderBottomWidth: 0, borderRadius: 13, paddingHorizontal: 11, marginTop: 2 },
  resultLabels: { flex: 1 },
  resultLabel: { fontSize: 13, lineHeight: 19, fontWeight: '500' },
  resultRowUrdu: { fontSize: 12, lineHeight: 17 },
  resultValue: { fontSize: 16, lineHeight: 22, fontWeight: '700', textAlign: 'right' },
  prominentValue: { fontSize: 20, lineHeight: 27 },
});